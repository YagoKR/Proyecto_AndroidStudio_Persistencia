package wirtz.examen.examendiciembre.actividades;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Base64;

import wirtz.examen.examendiciembre.R;
import wirtz.examen.examendiciembre.adaptadores.FicheroAdapter;
import wirtz.examen.examendiciembre.bbdd.daos.FicheroDAO;
import wirtz.examen.examendiciembre.bbdd.entidades.Fichero;

public class VisualizarActivity extends AppCompatActivity {
    public FicheroDAO fichDAO;
    public Fichero fichSelec;
    public ArrayList<Fichero> arr;
    public ArrayList<Fichero> arrFiltrados;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_visualizar);

        fichDAO = new FicheroDAO(getApplicationContext());
        arr = fichDAO.visualizarDatos();
        arrFiltrados = new ArrayList<>(arr);

        FicheroAdapter fichAdaptador = new FicheroAdapter(getApplicationContext(), arrFiltrados);
        ListView listFicheros = findViewById(R.id.lvFicheros);
        listFicheros.setAdapter(fichAdaptador);
        listFicheros.setOnItemClickListener((parent, view, position, id) -> {
            fichSelec = arrFiltrados.get(position);
        });

        listFicheros.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Fichero ficheroSeleccionado = arrFiltrados.get(position);
                Intent intent = new Intent(VisualizarActivity.this, EditarActivity.class);
                intent.putExtra("fichero", ficheroSeleccionado);
                startActivity(intent);
                return true;
            }
        });
        CheckBox cbMostrarBorradores = findViewById(R.id.ckSoloBorradores);
        cbMostrarBorradores.setOnCheckedChangeListener((buttonView, isChecked) -> {
            arrFiltrados.clear();
            if (isChecked) {
                for (Fichero fichero : arr) {
                    if ("borrador".equalsIgnoreCase(fichero.getEstado())) {
                        arrFiltrados.add(fichero);
                    }
                }
            } else {
                arrFiltrados.addAll(arr);
            }
            fichAdaptador.notifyDataSetChanged();

        });

        Button btnBorrar = findViewById(R.id.btEliminarFicheros);

        btnBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(VisualizarActivity.this);
                alert.setTitle("Confirmación");
                alert.setMessage("¿Estás seguro de que deseas eliminar el archivo \"" + fichSelec.getNombre() + "\"?");
                alert.setPositiveButton("Eliminar", (dialog, which) -> {

                    fichDAO.eliminarDato(fichSelec);

                    arr.remove(fichSelec);
                    arrFiltrados.remove(fichSelec);
                    fichAdaptador.notifyDataSetChanged();

                    fichSelec = null;

                    Toast.makeText(VisualizarActivity.this, "Archivo eliminado con éxito", Toast.LENGTH_SHORT).show();
                });
                alert.setNegativeButton("Cancelar", null);
                alert.show();
            }
        });

    }


}