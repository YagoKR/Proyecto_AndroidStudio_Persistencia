package wirtz.examen.examendiciembre.bbdd.definicion;

import android.provider.BaseColumns;

public class ExamenDbContract {

    public final class tbNotas implements BaseColumns {
        public static final String TABLE_NAME = "notas";
        public static final String COLUMN_NOMBRE = "nombre";
        public static final String COLUMN_CONTENIDO = "contenido";
        public static final String COLUMN_IMAGEN = "imagen";
        public static final String COLUMN_ESTADO = "estado";
    }

    public static final String SQL_CREATE_ENTRIES = "CREATE TABLE " + tbNotas.TABLE_NAME + " ("
            + tbNotas._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + tbNotas.COLUMN_NOMBRE + " TEXT, "
            + tbNotas.COLUMN_CONTENIDO + " TEXT, "
            + tbNotas.COLUMN_IMAGEN + " TEXT, "
            + tbNotas.COLUMN_ESTADO + " TEXT)";

    public static final String SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS " + tbNotas.TABLE_NAME;

}
