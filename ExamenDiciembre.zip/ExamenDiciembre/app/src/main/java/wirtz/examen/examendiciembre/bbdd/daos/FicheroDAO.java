package wirtz.examen.examendiciembre.bbdd.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.BaseColumns;

import java.util.ArrayList;
import java.util.Base64;

import wirtz.examen.examendiciembre.bbdd.definicion.ExamenSQLiteHelper;
import wirtz.examen.examendiciembre.bbdd.entidades.Fichero;

public class FicheroDAO {
    private SQLiteDatabase db;

    public FicheroDAO(Context context) {
        ExamenSQLiteHelper dbHelper = new ExamenSQLiteHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public long insertarDatos(Fichero fichero) {
        ContentValues values = new ContentValues();
        values.put ("nombre", fichero.getNombre());
        values.put ("contenido", fichero.getContenido());
        values.put ("imagen", fichero.getImagen());
        values.put ("estado", fichero.getEstado());
        return db.insert ("notas", null, values);
    }

    public ArrayList <Fichero> visualizarDatos() {

        ArrayList<Fichero> arr = new ArrayList<>();
        String[] projection = {"nombre", "contenido", "imagen", "estado"};

        Cursor cursor = db.query("notas", projection, null, null, null, null, null);
        while (cursor.moveToNext()) {
            String nombre = cursor.getString(cursor.getColumnIndexOrThrow("nombre"));
            String contenido = cursor.getString(cursor.getColumnIndexOrThrow("contenido"));
            String imagen = cursor.getString(cursor.getColumnIndexOrThrow("imagen"));
            String estado = cursor.getString(cursor.getColumnIndexOrThrow("estado"));
            Fichero f = new Fichero(nombre, contenido,imagen);
            f.setEstado(estado);
            arr.add(f);
        }
        cursor.close();
        return arr;
    }

    public int eliminarDato (Fichero fichero) {
        String selection = "nombre like ?";
        String [] selectionArgs = {fichero.getNombre()};
        return db.delete("notas", selection, selectionArgs);
    }

    public int actualizarDatos (Fichero fichero) {
        ContentValues values = new ContentValues();
        values.put ("contenido", fichero.getContenido());
        values.put ("imagen", fichero.getImagen());
        values.put ("estado", fichero.getEstado());
        String selection = "nombre like ?";
        String [] selectionArgs = {fichero.getNombre()};
        return db.update("notas", values, selection, selectionArgs);
    }

}
