package wirtz.examen.examendiciembre.bbdd.entidades;

import java.io.Serializable;

public class Fichero implements Serializable {

    private long id;
    private String nombre;
    private String contenido;
    private String imagen;
    private String estado;

    public Fichero() {
    }

    public Fichero(String nombre, String contenido, String imagen) {
        this.nombre = nombre;
        this.contenido = contenido;
        this.imagen=imagen;
    }


    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
}
