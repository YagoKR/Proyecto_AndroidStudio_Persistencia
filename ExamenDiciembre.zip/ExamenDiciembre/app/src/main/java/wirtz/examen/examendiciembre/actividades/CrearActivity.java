package wirtz.examen.examendiciembre.actividades;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.ByteArrayOutputStream;
import java.util.Base64;

import wirtz.examen.examendiciembre.R;
import wirtz.examen.examendiciembre.bbdd.daos.FicheroDAO;
import wirtz.examen.examendiciembre.bbdd.entidades.Fichero;

public class CrearActivity extends AppCompatActivity {

    private EditText etNombre;
    private EditText etContenido;
    private Button btGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_crear);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        etNombre=findViewById(R.id.etNombre);
        etContenido=findViewById(R.id.etContenido);
        btGuardar=findViewById(R.id.btGuardar);

        btGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = etNombre.getText().toString();
                String contenido = etContenido.getText().toString();
                Bitmap imagenBorrador = BitmapFactory.decodeResource(getResources(), R.raw.borrador);
                String imagenBase64 = bitmapToBase64(imagenBorrador);

                Fichero f = new Fichero(nombre, contenido, imagenBase64);
                f.setEstado("borrador");

                FicheroDAO fDAO = new FicheroDAO(getApplicationContext());
                fDAO.insertarDatos(f);

                Toast.makeText(CrearActivity.this, "Datos guardados con éxito", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String bitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        byte[] byteArray = outputStream.toByteArray();
        return Base64.getEncoder().encodeToString(byteArray);
    }

}