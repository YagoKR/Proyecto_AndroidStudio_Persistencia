package wirtz.examen.examendiciembre.actividades;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.ByteArrayOutputStream;
import java.util.Base64;

import wirtz.examen.examendiciembre.R;

import wirtz.examen.examendiciembre.bbdd.daos.FicheroDAO;
import wirtz.examen.examendiciembre.bbdd.entidades.Fichero;

public class EditarActivity extends AppCompatActivity {

    SQLiteDatabase db=null;
    EditText etNombre,etContenido,etContenidoFichero;
    Fichero fichero;
    Button btGuardar;
    Button btRevisar;

    public FicheroDAO fichDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_editar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        fichDAO = new FicheroDAO(getApplicationContext());

        btGuardar=findViewById(R.id.btGuardar);
        btGuardar.setEnabled(false);
        btRevisar=findViewById(R.id.btRevisar);
        btRevisar.setEnabled(true);
        etNombre=findViewById(R.id.etNombre);
        etNombre.setEnabled(false);
        etContenido = findViewById(R.id.etContenido);
        etContenido.setEnabled(false);
        etContenidoFichero=findViewById(R.id.etContenidoFichero);
        etContenidoFichero.setEnabled(false);


        Intent i= getIntent();
        fichero= (Fichero) i.getSerializableExtra("fichero",Fichero.class);


        if (fichero != null) {
            etNombre.setText(fichero.getNombre());
            etContenido.setText(fichero.getContenido());
        }

        btRevisar.setOnClickListener(v -> {
            etContenidoFichero.setEnabled(true);
            btGuardar.setEnabled(true);
            btRevisar.setEnabled(false);
        });

        btGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = etNombre.getText().toString();
                String nuevoContenido = etContenidoFichero.getText().toString();
                Bitmap imagenDefinitivo = BitmapFactory.decodeResource(getResources(), R.raw.definitivo);
                String imagenBase64 = bitmapToBase64(imagenDefinitivo);

                Fichero f = new Fichero(nombre, nuevoContenido, imagenBase64);
                f.setEstado("definitivo");

                FicheroDAO fDAO = new FicheroDAO(getApplicationContext());
                fDAO.actualizarDatos(f);
                btGuardar.setEnabled(false);
                etContenidoFichero.setEnabled(false);
                Toast.makeText(EditarActivity.this, "Datos actualizados con éxito", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String bitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        byte[] byteArray = outputStream.toByteArray();
        return Base64.getEncoder().encodeToString(byteArray);
    }
}