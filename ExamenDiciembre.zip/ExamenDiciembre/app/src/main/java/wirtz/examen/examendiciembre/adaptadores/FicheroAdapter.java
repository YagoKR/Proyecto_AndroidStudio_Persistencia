package wirtz.examen.examendiciembre.adaptadores;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Base64;

import wirtz.examen.examendiciembre.R;
import wirtz.examen.examendiciembre.bbdd.entidades.Fichero;

public class FicheroAdapter extends BaseAdapter {

    private ArrayList<Fichero> ficheros;
    private Context context;

    public FicheroAdapter(Context context, ArrayList<Fichero> ficheros) {
        this.context = context;
        this.ficheros = ficheros;
    }

    @Override
    public int getCount() {
        return ficheros.size();
    }

    @Override
    public Object getItem(int position) {
        return ficheros.get(position);
    }

    @Override
    public long getItemId(int position) {
        return ficheros.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Fichero f = (Fichero) getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_fichero, parent, false);
        }
        TextView textViewNombre= convertView.findViewById(R.id.tvNombre);
        TextView textViewEstado = convertView.findViewById(R.id.tvEstado);
        ImageView imagenEstado = convertView.findViewById(R.id.ivEstado);

        Bitmap imagenBit = base64ToBitmap(f.getImagen());
        textViewNombre.setText(f.getNombre());
        textViewEstado .setText(f.getEstado());
        imagenEstado.setImageBitmap(imagenBit);

        return convertView;
    }

    private Bitmap base64ToBitmap(String base64String) {
        byte[] decodedBytes = Base64.getDecoder().decode(base64String);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
}
